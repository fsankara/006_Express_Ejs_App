module.exports = [
{
    id:1,
    gun: "Pazartesi",
    ders : ["Türkçe", "Türkçe", "Matematik", "Görsel Sanatlar", "İngilizce", "İngilizce", "Göresel Sanatlar"],
},

{
    id:2,
    gun: "Salı",
    ders : ["Görsel Sanatlar", "Beden Eğitimi", "Beden Eğitimi", "Din", "Din", "Matematik", "Matematik"],
},

{
    id:3,
    gun: "Çarşamba",
    ders : ["Fen", "Fen", "Matematik", "Matematik", "İngilizce", "Müzik", "Türkçe"],
},

{
    id:4,
    gun: "Perşembe",
    ders : ["Bilişim", "Bilişim", "Sosyal", "Türkçe", "Türkçe", "İngilizce", "İngilizce"],
},

{
    id:5,
    gun: "Cuma",
    ders : ["Fen", "Fen", "Sosyal", "Sosyal", "Okuma Becerileri", "Okuma Becerileri", "Türkçe"],
},

]
